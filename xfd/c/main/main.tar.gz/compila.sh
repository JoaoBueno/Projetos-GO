go build -o $1.so -buildmode=c-shared $1.go
